#include "mbed.h"
#include "LSM9DS1.h"
#include "Motor.h"
#include "rtos.h"
#include <cmath>
#include "TextLCD.h"
#define PI 3.14159
// Earth's magnetic field varies by location. Add or subtract
// a declination to get a more accurate heading. Calculate
// your's here:
// http://www.ngdc.noaa.gov/geomag-web/#declination
#define DECLINATION -4.94 // Declination (degrees) in Atlanta,GA.
double D;
bool inPosition;
volatile float bearing = 0;
volatile float heading;
TextLCD lcd(p12, p8, p9, p10, p11, p6); // rs, e, d4-d7
RawSerial  gps(p13,p14);
char cDataBuffer[500];
void parse(char *cmd, int n);
float pi = 3.1415;
struct coordinates{float lat; float lon;};
float angle;
coordinates average;
float range;
int i = 0;
coordinates points[5];
coordinates currentPosition;
DigitalOut myled(LED1);
LSM9DS1 IMU(p28, p27, 0xD6, 0x3C);
Serial pc(USBTX, USBRX);
Motor L(P2_5, p22, p23); //A
Motor R(P2_0,p25, p24); //B
// Calculate pitch, roll, and heading.
// Pitch/roll calculations taken from this app note:
// http://cache.freescale.com/files/sensors/doc/app_note/AN3461.pdf?fpsp=1
// Heading calculations taken from this app note:
// http://www51.honeywell.com/aero/common/documents/myaerospacecatalog-documents/Defense_Brochures-documents/Magnetic__Literature_Application_notes-documents/AN203_Compass_Heading_Using_Magnetometers.pdf
void printAttitude(float ax, float ay, float az, float mx, float my, float mz)
{
    float roll = atan2(ay, az);
    float pitch = atan2(-ax, sqrt(ay * ay + az * az));
// touchy trig stuff to use arctan to get compass heading (scale is 0..360)
    mx = -mx;
    if (my == 0.0)
        heading = (mx < 0.0) ? 180.0 : 0.0;
    else
        heading = atan2(mx, my)*360.0/(2.0*PI);
    //pc.printf("heading atan=%f \n\r",heading);
    heading -= DECLINATION + 90; //correct for geo location
    if(heading>180.0) heading = heading - 360.0;
    else if(heading<-180.0) heading = 360.0 + heading;
    else if(heading<0.0) heading = 360.0  + heading;
}
void compass() {
        while(!IMU.tempAvailable());
        IMU.readTemp();
        while(!IMU.magAvailable(X_AXIS));
        IMU.readMag();
        while(!IMU.accelAvailable());
        IMU.readAccel();
        while(!IMU.gyroAvailable());
        IMU.readGyro();
        printAttitude(IMU.calcAccel(IMU.ax), IMU.calcAccel(IMU.ay), IMU.calcAccel(IMU.az), IMU.calcMag(IMU.mx),
                      IMU.calcMag(IMU.my), IMU.calcMag(IMU.mz));
}
void point() {
    bool pointed = 0;
    while (!pointed) {
        pointed = 1;
        compass();
        if (bearing - (heading - 180) < 175) {
            if ((bearing - (heading - 180)) > 185 || (bearing - (heading - 180)) < 175) {
                myled = 0;
                L.speed(-.5);
                R.speed(.5);
                Thread::wait(60);
                L.speed(0);
                R.speed(0);
                pointed = 0;
            }
        } else if (bearing - (heading - 180) > 185) {
            if ((bearing - (heading - 180)) > 185|| (bearing - (heading - 180)) < 175) {
                myled = 0;
                L.speed(.6);
                R.speed(-.6);
                Thread::wait(60);
                L.speed(0);
                R.speed(0);
                pointed = 0;
            }
        } 
        Thread::wait(100);
    }
}

float decimalize(float cord) {
    float cord_decimal, cord_minutes;
    int cord_firstdig;
    cord_firstdig = ((int)(cord/100))/1;
    cord_minutes = (cord - cord_firstdig*100);
    cord_decimal = cord_firstdig + cord_minutes/60;
    return cord_decimal;
}

float distance_func (float lat1, float long1, float lat2, float long2) {
    float phi1, phi2, dlamda;
    phi1 = lat1 * pi/180;
    phi2 = lat2 * pi/180;
    dlamda = (long2-long1) * pi/180;
    float R = 6371e3;
    float x = dlamda * cos(phi1+phi2) / 2;
    float y = (phi2 - phi1);
    float d = R * sqrt(x*x + y*y);
    return d;
}
void gpsfilter(coordinates* in, coordinates* avg) {
    int window = 5;
    avg->lat = (in->lat + avg->lat*(window-1))/window;
    avg->lon = (in->lon + avg->lon*(window-1))/window;
}
void parse(char *cmd, int n, coordinates* info)
{
    float lat_decimalfinal,long_decimalfinal;
    char ns, ew, tf, status;
    int fq, nst, fix, date;                                     // fix quality, Number of satellites being tracked, 3D fix
    float latitude, longitude, timefix, speed, altitude;
    float hoop_lat = 33.776608;
    float hoop_long = -84.395029;
    float distance;


    
    // Geographic position, Latitude and Longitude
    if(strncmp(cmd,"$GPGLL", 6) == 0) 
    {
        myled =1;
        sscanf(cmd, "$GPGLL,%f,%c,%f,%c,%f", &latitude, &ns, &longitude, &ew, &timefix);
        lat_decimalfinal = decimalize(latitude);
        long_decimalfinal = 0 - decimalize(longitude);
        myled = 0;
        info->lat = lat_decimalfinal;
        info->lon = long_decimalfinal;
        gpsfilter(info, &average);
        lcd.locate(0, 0);
        lcd.printf("LAT: %f\nLON: %f", average.lat, average.lon);
    }
}

int bearing_calc(float lat1, float long1, float lat2, float long2) {
    float phi1, phi2, dlamda;
    phi1 = lat1 * pi/180;
    phi2 = lat2 * pi/180;
    dlamda = (long2-long1) * pi/180;
    float y = sin(dlamda) * cos(phi2);
    float x = cos(phi1)*sin(phi2) - sin(phi1)*cos(phi2)*cos(dlamda);
    float theta = atan2(y,x);
    float degree = theta*180;
    degree = degree / pi;
    return ((int)(degree + 360)) %360;
}


void gps_thread(void const *args){ 
    char c;

    while(true) 
    {
        if(gps.readable())
        { 
            if(gps.getc() == '$');           // wait a $
            {
                for(int i=0; i<sizeof(cDataBuffer); i++)
                {
                    c = gps.getc();
                    if( c == '\r' )
                    {
                        //pc.printf("%s\n", cDataBuffer);
                        parse(cDataBuffer, i, &currentPosition);
                        i = sizeof(cDataBuffer);
                    }
                    else
                    {
                        cDataBuffer[i] = c;
                    }                 
                }
            }
         } 
    }
}


int main()
{   float dheading;
    Thread gps1(&gps_thread);
    points[0].lat = 33.77551507761366;
    points[0].lon = -84.39673534506171;
    points[1].lat = 33.77526034958517;
    points[1].lon = -84.39673337405817;
    points[2].lat = 33.77525708537966;
    points[2].lon = -84.39691990579253;
    points[3].lat = 33.77536317199526;
    points[3].lon = -84.39706716768806;
    points[4].lat = 33.77551507761366;
    points[4].lon = -84.39673534506171;
    pc.baud(115200);
    gps.baud(9600);
    IMU.begin();
    IMU.calibrate(1);
    L.speed(-.5);
    R.speed(.5);
    IMU.calibrateMag(0);
    L.speed(0);
    R.speed(0);
    average.lat = currentPosition.lat;
    average.lon = currentPosition.lon;
    while(1) {
        if (i < 5) {
            Thread::wait(100);
            compass();
            //pc.printf("lat:%f       long:%f\n", currentPosition.lat, currentPosition.lon);
            bearing = bearing_calc(average.lat, average.lon, points[i].lat, points[i].lon);
            range =distance_func(average.lat, average.lon, points[i].lat, points[i].lon);
            //pc.printf("angle: %f        range:%f\n", angle, range);
            //pc.printf("heading: %f  angle: %f   diff: %f\n", heading, angle, dheading);
            if (range > 1) {
                point();
                R.speed(1);
                L.speed(1);
                Thread::wait(350);
                R.speed(0);
                L.speed(0);
            } if (range < 1) {
                i +=1;
            } 
        } else {
            while (1) {
            myled = !myled;
            Thread::wait(.2);
            }
        }
    }
}


